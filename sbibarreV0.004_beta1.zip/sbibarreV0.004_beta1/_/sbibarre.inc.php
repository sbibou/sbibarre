<?php
##########################
##   Sbibarre concept !
##
## Version 0.004 Beta 1
##       07/07/2018 
#########################
##      Olivier Ros
##
##   olivier@sbibou.com
## http://sbibou.com/sbibarre
##     
##
##
##########################
## ../_/sbibarre.inc.php
##########################

## afficher ou pas les erreurs
##ini_set('display_errors','1');

## the name of the file where you will put your links
$filename = './sbibarre.txt';
if(!isset($diradmin)){$diradmin = 'gere';}
## right menu
$menu2 = '<b>Editor </b><a href="http://sbibou.com/sbibarre/_/editorhtml.php" target="droite">html</a> | <a href="http://sbibou.com/sbibarre/_/editorbb.php" target="droite">bb code</a>';


## the style and menu' s begin
$menu = '
<style>
#menu-accordeon {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
  width: 180px;
}
#menu-accordeon ul {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
}
#menu-accordeon li {
   background-color:#729EBF; 
   background-image:-webkit-linear-gradient(top, #729EBF 0%, #333A40 100%);
   background-image: linear-gradient(to bottom, #729EBF 0%, #333A40 100%);
   border-radius: 6px;
   margin-bottom:2px;
   box-shadow: 3px 3px 3px #999;
   border:solid 1px #333A40
}
#menu-accordeon li li {
   max-height:0;
   overflow: hidden;
   transition: all .5s;
   border-radius:0;
   background: #444;
   box-shadow: none;
   border:none;
   margin:0
}
#menu-accordeon a {
  display:block;
  text-decoration: none;
  color: #fff;
  padding: 8px 0;
  font-family: verdana;
  font-size:1.2em
}
#menu-accordeon ul li a, #menu-accordeon li:hover li a {
  font-size:1em
}
#menu-accordeon li:hover {
   background: #729EBF
}
#menu-accordeon li li:hover {
   background: #999;
}
#menu-accordeon ul li:last-child {
   border-radius: 0 0 6px 6px;
   border:none;
}
#menu-accordeon li:hover li {
  max-height: 15em;
}
</style>
<nav>
<h3>Sbibarre menu ;)';
if(isset($_SESSION['admin'])){$menu .= '<a target="bas"  href="'.$chemin.$diradmin.'"><b>Administration</b></a><hr />';}
$menu .= '<a href="https://rosaff.com/support/index.php?a=add&catid=6" target="bas">(Support)</a>
<a href="https://rosaff.com/support/knowledgebase.php?category=18" target="bas">(Faq)</a>
<a href="http://sbibou.com/sbibarre" target="bas">(Page)</a>
<a href="https://ssolos.com/forum/phpBB3/viewforum.php?f=10" target="bas">(forum)</a></h3>
<hr />

	';
## if your link's page exist
if(is_file($filename)){ 
	
	
## we open it for read
$sbtxt = fopen($filename, 'r') or die('Unable to open file!');
//$contents = fread($sbtxt, filesize($filename));
            while ( $contents = fgets($sbtxt) ) 
            
            { 
//////////////////		we explode the file to retrieve $url, $text & $target		
                list($url, $text, $target) = explode(" : ", $contents);
               if(($url == '@*@') || ($url == '@@@'))
               {
                if($url == '@*@'){
					$menu .= '
					<ul id="menu-accordeon">
					<li><a href="#">'.$text.'
					<ul>
					';$menu .= "\n";
					}
				if($url == '@@@'){
					$menu .= '</ul>
					</li></ul>
						';
					}
				}
                else
                {
				$target = str_replace("\n", "", $target);
                $target = str_replace("\r", "", $target);
                $target = str_replace("\t", "", $target);
                //$chaine=preg_replace("#\n|\t|\r#","",$target);
                $menu .= '<li><a href="'.$url.'" target="'.$target.'">'.$text.'</a></li>'; 
                $menu .= "\n";
                }

//////////////////////
            } 
fclose($sbtxt);
## I will soon find better than that lol
$menu = str_replace('<li><a href="@@@
" target=""></a></li>', '', $menu);
//$menu = str_replace('@*@', '#', $menu);
$menu .= '
<hr /><a href="https://sourceforge.net/projects/sbibarre/" target="_blank">
<img src="http://sbibou.com/img/sbibarre-125.png" />
<img alt="Download sbibarre" src="https://img.shields.io/sourceforge/dm/sbibarre.svg" ></a>
<br />
<a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/" target="_blank">
<img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a>
<br />
This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/" target="_blank">
Creative Commons Attribution-ShareAlike 4.0 International License</a>.
<br />';

}

else
{
	$menu .= '
					<ul id="menu-accordeon">
					<li><a href="#">My Favorites
					<ul>
					
<li><a href="http://sbibou.com" target="bas">Sbibou.com</a></li>
<li><a href="http://google.com" target="_blank">Google</a></li>
</ul>
					</li></ul>
						
					<ul id="menu-accordeon">
					<li><a href="#">Sbibou Network
					<ul>
					
<li><a href="http://sbibou.com" target="bas">Sbibou.com</a></li>
<li><a href="http://ssolos.com" target="bas">SSolos.com</a></li>
<li><a href="http://contactmymembers.com" target="bas">ContactMyMembers.com</a></li>
<li><a href="http://safelists.co" target="bas">Safelists.co</a></li>
<li><a href="http://listbuilderads.info" target="bas">ListBuilderAds</a></li>
<li><a href="http://rosaff.com" target="bas">RosAff.com</a></li>
<li><a href="http://o-ros.com" target="bas">O-Ros.com</a></li>
<li><a href="http://script.cool" target="bas">Script.cool</a></li>
<li><a href="http://olios.click" target="bas">Olios.click</a></li>
<li><a href="http://weblogeur.com" target="bas">weblogeur.com</a></li>
<li><a href="http://adsimum.com" target="bas">Adsimum.com</a></li>
<li><a href="http://2safelist.com" target="bas">2safelist</a></li>
</ul>
					</li></ul>
						
					<ul id="menu-accordeon">
					<li><a href="#">Tools
					<ul>
					
<li><a href="http://instantbannercreator.com/?rid=50763" target="bas">instantbannercreator</a></li>
<li><a href="http://intellibanners.com/?rid=16680" target="bas">intellibanners</a></li>
<li><a href="http://hitsconnect.com/?rid=45462" target="bas">hitsconnect.com</a></li>
<li><a href="http://www.entireweb.com/free_submission/#sbibou" target="_blank">entireweb</a></li>
<li><a href="https://techmasi.com/ping-sites/" target="bas">ping</a></li>
<li><a href="http://www.viralrotator.com/index.php?ref=3555" target="bas">viralrotator</a></li>
<li><a href="http://www.skyadboard.com/?pro=1126" target="bas">skyadboard</a></li>
<li><a href="http://listbuilderads.info/NewbieLessons" target="bas">NewbieLessons</a></li>
<li><a href="http://listbuilderads.info/store/storefront/index.php" target="bas">Opportunities</a></li>
</ul>
					</li></ul>
						
					<ul id="menu-accordeon">
					<li><a href="#">Links
					<ul>
					
<li><a href="http://1profitring.com/sbibou" target="bas">1profitring</a></li>
<li><a href="http://1tae.com/sbibou" target="bas">1tae</a></li>
<li><a href="http://577cash.com/sbibou" target="bas">577cash</a></li>
<li><a href="https://blaster.guru/sbibou" target="bas">blaster guru</a></li>
<li><a href="https://superlistexplode.com/sbibou" target="bas">superlistexplode</a></li>
<li><a href="https://wondermailer.com/sbibou" target="bas">wondermailer</a></li>
<li><a href="http://sbibou.com" target="bas">Sbibou.com</a></li>
<li><a href="http://google.com" target="_blank">Google</a></li>
</ul>
					</li></ul>
						
					<ul id="menu-accordeon">
					<li><a href="#">Social
					<ul>
					
<li><a href="http://ssolos.com/forum" target="bas">SSolos Forum</a></li>
<li><a href="http://safelists.co/forum" target="bas">Safelists.co Forum</a></li>
<li><a href="https://www.facebook.com/sbibousystem/" target="_blank">facebook</a></li>
</ul>
					</li></ul>
						</ul>
					</li></ul>
						
					<ul id="menu-accordeon">
					<li><a href="#">Engines
					<ul>
					
<li><a href="http://rosaff.com/php-chunked-xhtml" target="bas">PHP</a></li>
<li><a href="https://dev.mysql.com/doc/" target="_blank">Mysql</a></li>
<li><a href="https://www.w3schools.com/" target="_blank">w3schools</a></li>
</ul>
					</li></ul>
					</nav>
					<hr />
					<a href="https://sourceforge.net/projects/sbibarre/files/latest/download" target="_blank">
					<img alt="Download sbibarre" src="https://img.shields.io/sourceforge/dm/sbibarre.svg" ></a>
					<br />
					<a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/" target="_blank">
					<img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a>
					<br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">
					Creative Commons Attribution-ShareAlike 4.0 International License</a>.
<br />
					';
}					
?>





