


<?php
 ######################################
 ###    Administration cms sbibou   ###
 ###        Special sbibarre        ###
 ###    1967-2018 © Ros Olivier     ###
 ###      Version 0.004 Beta 1      ###
 ###     ./_/gere/index.php         ###
 ###      Documentation sur         ###
 ###http://sbibou.com/sbibou_cms/doc###
 ######################################
 ## Version du cms
 $sb_version = '0.004.b1';
 ##########################

ini_set('display_errors','1');

$chemin = '../../';
define('CHEMIN',$chemin);
$titre_page = 'Administration - '.$_SERVER['SERVER_NAME'];
define('TITRE_PAGE', $titre_page);
if(is_file($chemin.'_/inc/fonctions.inc.php')){
require $chemin.'_/inc/fonctions.inc.php';
}
else{
	#####################
## fonction header
function h_html(){
	global $chemin,$titre_page;
	if(file_exists($chemin.'_/inc/header.inc')){
	include $chemin.'_/inc/header.inc';
	}
	else
	{
	print '<!DOCTYPE html>
<html lang="en-us">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="sbibarre administration- sbibou.com"/>
<title>'.$titre_page.'</title>
<meta http-equiv="content-type" content="text/hml; charset=UTF-8">
<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8"/>
<meta name="generator" content="sbiboucms v0.003b1" />
<meta name="author" content="olivier ros" />
<meta name="date" content="2018-07-02T15:27:41+0200" />
<meta name="copyright" content="olivier ros"/>
<meta name="keywords" content=""/>
<meta name="description" content=""/>
<meta name="ROBOTS" content="ALL"/>
<link rel="image_src" href="http://sibou.com/favicon.png" />


</head>
<body>


<div align="left">
<h2><a href="'.$chemin.'">
<img width="52" height="52"   src="http://sbibou.com/favicon.png" />Sbibarre</a></h2>
</div><div align="center">';
}}
###
##########

###################
## Fonction footer
function b_html(){
	global $chemin;
if(file_exists($chemin.'_/inc/footer.inc')){
include $chemin.'_/inc/footer.inc';
}
else{
echo '
<hr />&bull;




<div id="copyright" name="copyright" class="copyright">Olivier Ros &copy; 2009-2018
<br /><a href="https://sbibou.com/sbibarre/doc/status.php">Status</a></div>
<br /><br />
<P ALIGN="RIGHT"></P>
<div class="thatsallfoks"><a href="http://o-ros.com" title="olivier Ros">O-Ros.com CEO Sbibou Network</a></div>
</body>
</html>';
}
}
##
##########


}
if(!isset($diradmin)){$diradmin = 'gere';}
#################
## fonction chmod récursif

function chmodr($path, $filemode) {
    if (!is_dir($path))
        return chmod($path, $filemode);

    $dh = opendir($path);
    while (($file = readdir($dh)) !== false) {
        if($file != '.' && $file != '..') {
            $fullpath = $path.'/'.$file;
            if(is_link($fullpath))
                return FALSE;
            elseif(!is_dir($fullpath) && !chmod($fullpath, $filemode))
                    return FALSE;
            elseif(!chmodr($fullpath, $filemode))
                return FALSE;
        }
    }

    closedir($dh);

    if(chmod($path, $filemode))
        return TRUE;
    else
        return FALSE;
}

##
################
if(isset($_POST['nom'])){
$ftp_server= $_SERVER['SERVER_NAME'];
$conn_id = ftp_connect($ftp_server);
$ftpnom = $_POST['nom'];
$ftpmotdepasse = $_POST['ftpmotdepasse'];
$ftpfichier = str_replace('index.php', '', $_SERVER['SCRIPT_FILENAME']);
$ftpchmod = $_POST['ftpchmod'];

// Connect to FTP server
$conn = ftp_connect($ftp_server);
if (!$conn) die('Unable to connect to '.$ftp_server.' dommage');

// Login as "user" with password "pass"
if (!ftp_login($conn, $ftpnom, $ftpmotdepasse)) die('Error logging into '.$ftp_server);

// Issue: "SITE CHMOD 0600 /home/user/privatefile" command to ftp server
if (ftp_site($conn, 'CHMOD '.$ftpchmod.' '.$ftpfichier)) {
   echo "Command executed successfully.\n";
} else {
   die('Command failed.');}

}
	if (!is_file('./.htaccess') && (!is_file('./.htpasswd')))
	{
#########
##
if(isset($_GET['method']) && ($_GET['method'] == 'writeht'))
{
$racine_admin = realpath('./index.php');
$racine = str_replace('index.php', '', $racine_admin);
$htaccess = fopen('.htaccess', 'w+');
$texte = 'AuthName "admin" 
AuthType Basic
AuthUserFile "'.$racine.'.htpasswd"
Require valid-user';
fwrite($htaccess, $texte);
fclose($htaccess);
echo '/htaccess créé';
$htpasswd = fopen('.htpasswd', 'w+');
$passcrypt = 'admin:'.crypt($_POST['pass']);
fwrite($htpasswd, $passcrypt);
fclose($htpasswd);
echo '/passwd créé';
echo '<a href="?">Go to admin now</a>';
exit;
}

##
#########
echo 'this file don t work without<br />
<ul><li>.htaccess</li><li>.htpasswd</li></ul> in same directory...
';
 	if (!is_writable('./'))
 	 {
echo 'Je <b>ne peux pas écrire</b> dans ce répertoire<br />
	Je vais tenter de chmoder en tant qu\' utilisateur apache...<br />'; 	 	
 	 	if(chmodr('./',0775)){echo'chmod reussi';$chmod_ok = 'oui';}else{echo '<b>chmod échoué</b>';$chmod_ok = 'non';}
 	 	if($chmod_ok == 'non')
 	 	{
 	 		echo 'Vous pouvez chmoder ce dossier en rentrant vos codes ftp...<br /><br />
 	 		Je vais tenter de chmoder en utilisant le serveur localhost et le port 21<br />
 	 		(Pour d\' autres ports ou serveur, on verra dans d\' autres versions...vous pouvez bien sur utiliser votre client ftp!!!)
<form method="post">
nom :<input name="nom" /><br />
Mot de passe<input name="ftpmotdepasse" type="password" /><br />
<input type="hidden" value="'.$_SERVER['PHP_SELF'].'" name="ftpfichier" />
<input type="hidden" value="775" name="ftpchmod" />
<input type="submit" value="chmoder" /> 	 		
 	 		';
 	 		
 	 	}
 	 }
 	 else{
#################
##
   echo '
<h3>we can write in this directory!cool!</h3>
<p>we will construct your admin protection</p>
<p>give us :</p>
<form method="post" action="?method=writeht">Password: <input name="pass"><input type="submit" value="submit"></form>

';
}





##
#################




}
else
{
	if (isset($_SERVER['PHP_AUTH_USER']) && (($_SERVER['PHP_AUTH_USER']) !== ''))
	{	
	
$mess ='';
if (version_compare(PHP_VERSION, '5.3.0', '<')) {
    $mqr=get_magic_quotes_runtime();
    set_magic_quotes_runtime(0);
}

if (get_magic_quotes_gpc()) {
    function stripslashes_deep($value)
    {
        $value = is_array($value) ?
                    array_map('stripslashes_deep', $value) :
                    stripslashes($value);

        return $value;
    }

    $_POST = array_map('stripslashes_deep', $_POST);
    $_GET = array_map('stripslashes_deep', $_GET);
    $_COOKIE = array_map('stripslashes_deep', $_COOKIE);
    $_REQUEST = array_map('stripslashes_deep', $_REQUEST);
}

##############################################
#### d abord les fonctions qui vont bien
##############################################

#########################################################
## EFFACER TOUT UN DOSSIER ET CE QU IL Y A DEDANS !!!! ##
## TRES DANGEREUX !!! ###
## <+()+> ##
function clearDir($dossier) {
	$ouverture=@opendir($dossier);
	if (!$ouverture) return;
	while($fichier=readdir($ouverture)) {
		if ($fichier == '.' || $fichier == '..') continue;
			if (is_dir($dossier."/".$fichier)) {
				$r=clearDir($dossier."/".$fichier);
				if (!$r) return false;
			}
			else {
				$r=@unlink($dossier."/".$fichier);
				if (!$r) return false;
			}
	}
closedir($ouverture);
$r=@rmdir($dossier);
if (!$r) return false;
	return true;
}
##
#######################


/////////////////////
// si on efface un dossier
///////////

#######################
##
if(isset($_GET['dossier_action'] ) && ($_GET['dossier_action'] === 'effacer'))
{
$letruc = $_GET['racine'];

if($_GET['consentement_destruction'] == 'poubelle'){clearDir($letruc);
header('location:'.$_SERVER['PHP_SELF'].'?mess=dossier_efface&dossier=../');
}
else
{
$titre_page = 'attention - effacement d un fichier en cours';
$mess .= '
<h1>ATTENTION!!!!!</h1>
<h2>êtes vous vraiment sûr de ce que vous faîtes???</h2>
<h3>Vous allez effacer <b>'.$letruc.'</b></h3>
(ce sera irrémédiable pour tout ce qui se trouve à l\' interrieur).
<br />
Si vous voulez réellement <b>effacer ce dossier</b>,
<a href="'.$_SERVER['PHP_SELF'].'?racine='.$_GET['racine'].'&dossier_action=effacer&consentement_destruction=poubelle">Cliquer ICI</a><hr />
Sinon pour naviguer dans le dossier 
<a href="'.$_SERVER['PHP_SELF'].'?dossier='.$_GET['racine'].'">
Cliquer là</a>
<br /><br /><hr />';
}


}
##
##############

######################
##
if(isset($_GET['dossier']))
	{$racine = $_GET['dossier'].'/';}
elseif(isset($_POST['racine']))
	{$racine = $_POST['racine'].'/';}
	else
	{$racine = '../';}

$racine = str_replace('//','/',$racine);
if(isset($_GET['page_titre'])){$page_titre = $_GET['page_titre'];}
if(isset($_GET['racine'])){$racine = $_GET['racine'];}
/////////////////
// Si on poste
if($_POST)
{
if(!isset($_POST['action'])){$get='?edit=oui';}
$page_titre = $_POST['page_titre'];
$page_contenu = $_POST['page_contenu'];
#########################
$adresse = $page_titre;

	if(file_exists($adresse))
	{
	$mess .= 'attention, le fichier existe<br />';
		
		
	}
// Si on crée un dossier
if(isset($_POST['nom_dossier'])){
mkdir ($_POST['racine'].$_POST['nom_dossier'], 0777);
header('location:'.$_SERVER['PHP_SELF'].'?dossier='.$_POST['racine']);
}
//////////////
// Si on efface un fichier
elseif($_POST['action'] === 'effacer')
{
unlink($_POST['racine'].$_POST['page_titre']);
header('location:'.$_SERVER['PHP_SELF'].'?mess=fichier_efface&dossier='.$_POST['racine']);
//////////////
}

// Si on enregistre un fichier
elseif($_POST['action'] === 'ecraser')
{
		//if(is_dir($adresse)){$le_dossier = $adresse;}else{	$le_dossier = dirname($adresse).'/';}
	$inF = fopen("$racine$page_titre","w+");
	fputs($inF,$page_contenu);
	fclose($inF);
	chmod($racine.$page_titre, 0644);
header('location:'.$_SERVER['PHP_SELF'].'?dossier='.$racine.'&edit=oui&page_titre='.$page_titre.'&mess=fichier_enregistre');
	//////////////
}
/////////////////////

//
////////////////////





#########################


}
// Fin de si on poste
////////////////////////
$source = '';

///////////////////////
// si get edit
if(isset($_GET['edit']))
{
	if(isset($_GET['page_titre'])){$page_titre = $_GET['page_titre'];}
	if(isset($_GET['racine'])){$racine = $_GET['racine'];}
	$adresse = $racine.$page_titre;
$lines = file($adresse);
$titre = $page_titre;

	foreach($lines as $line)
	{
	$source .= $line;
       
	}
}
else
{$source .=  @$page_contenu;}
// fin de si get edit
///////////////////////
if(isset($_GET['mess'])){
if($_GET['mess'] === 'fichier_enregistre'){$mess .=  'Votre fichier est enregistré';}
if($_GET['mess'] === 'fichier_efface'){$mess .=  'Votre fichier est effacé';}
if($_GET['mess'] === 'dossier_efface'){$mess .=  'Votre dossier est effacé';}
}
##################



////////////////////   CHMOD   /////////////////////////////
///////////////

if(isset($_POST['chmod'])){
	$msg_chmod = 'message chmod <hr />';
$m_fichier = $_POST['fichier'];
$m_chmod = octdec($_POST['chmod']);
if($_POST['chmodr'] === 'oui')
{
if(chmodr("$m_fichier",$m_chmod)){$erreur = 'non';};
}
else
{
if(!chmod("$m_fichier",$m_chmod)){$erreur = 'oui';};
}
////
if($erreur === 'oui')
{
$msg_chmod .= '
Pas possible de chmoder!!! ==> chmod('.$m_fichier.','.$_POST['chmod'].')
<br />Vous n\' êtes vraissemblablement pas le propriétaire.<br />
<h2>Tenter de chmoder avec vos identifiant ftp???</h2>
<form action="'.$_SERVER['PHP_SELF'].'?ftpchmod=ouich" method="post">
<p>Nom : <input name="ftpnom" type="text" value="" /></p>
<p>Mot de passe : <input name="ftpmotdepasse" type="password" value="" /></p>
<input name="ftpchmod" type="hidden" value="'.$_POST['chmod'].'" />
<input name="ftpfichier" type="hidden" value="'.$m_fichier.'" />';
if(is_dir($m_fichier))
{$msg_chmod .= '
<input type="radio" name="chmodr" value="oui" />
<input type="radio" name="chmodr" value="non" />';
}
$msg_chmod .= '
<input type="submit" value="go go go" />
</form>';
}
else
{$msg_chmod .= 'bravo';
}

}
else
{
	$msg_chmod = 'message chmod :<hr />';
$_le_path = realpath(@$_GET['fichier']);
$msg_chmod .= '<form method="post">
<input type="text" name="chmod" value="'.@$_GET['chmod_actuel'].'" />
<input type="hidden" name="fichier" value="'.$_le_path.'" />
';
if(is_dir($_le_path))
{
	$msg_chmod .= '
	récursif :<input type="radio" name="chmodr" value="oui" />
ou pas :<input type="radio" name="chmodr" value="non" />
';
}
$msg_chmod .= '<input type="submit" value="changer les chmods" />
</form>';
}
// si chmod ftp

if(isset($_GET['ftpchmod'])){




$ftpserver='localhost';
$conn_id = ftp_connect("$ftp_server");
$ftpnom = $_POST['ftpnom'];
$ftpmotdepasse = $_POST['ftpmotdepasse'];
$ftpfichier = $_POST['ftpfichier'];
$ftpchmod = $_POST['ftpchmod'];

// Connect to FTP server
$conn = ftp_connect('localhost');
if (!$conn) die('Unable to connect to '.$ftpserver.' dommage');

// Login as "user" with password "pass"
if (!ftp_login($conn, $ftpnom, $ftpmotdepasse)) die('Error logging into '.$ftpserver);

// Issue: "SITE CHMOD 0600 /home/user/privatefile" command to ftp server
if (ftp_site($conn, 'CHMOD '.$ftpchmod.' '.$ftpfichier)) {
   echo "Command executed successfully.\n";
} else {
   die('Command failed.');}


/*
ftp_login($conn_id, $ftpnom, $ftpmotdepasse);
//ftp_mkdir($conn_id, dir/dir);
ftp_site($conn_id, 'CHMOD '.$ftpchmod, $ftpfichier) or die('raté');
ftp_close($conn_id);
*/
}


######################
##

		if (isset($_REQUEST['logout']))
		{

session_start();
unset($_SESSION);
unset($_COOKIE);
session_unset();
session_destroy();
header("WWW-Authenticate: Basic realm=\"admin\"");
header("HTTP/1.0 401 Unauthorized");


			exit('<a href="'.$chemin.'">you are not connected, <br />go to home now ;) </a>');

		}
		session_start();
	$admin = ($_SERVER['PHP_AUTH_USER']);
	$htpasswd = ($_SERVER['PHP_AUTH_PW']);
	$_SESSION['admin'] = 'ok';
$hello = '<a href="?">Hello '.$admin .' go to admin</a> - <a href="?logout">
	 '.$admin .' logout</a>
	('.$admin.')';
	} // pour le login 
	
##
######################	
	
	
if(!isset($_SESSION['admin'])){
	
h_html();	
	echo '<h1>You are not connected</h1>';

b_html();	
}
else
{
h_html();
///////////////
/////////////////////////////////////////////////


## affichage formulaire
echo '<a name="script">'.$mess.'</a><br />
'.$msg_chmod.'<br />
<h3>hello '.$admin.'</h3>
'.$hello.'
<div class="nav">
<ul><li>
	edit sbibarre.txt??? 
	<a href="?dossier=../&edit=oui&racine=../&page_titre=sbibarre.txt">
	 Click Here
	 </a></li>
	 <li>
		edit sbibarre.inc.php??? 
	<a href="?dossier=../&edit=oui&racine=../&page_titre=sbibarre.inc.php">
	 Click Here
	 </a> </li>
	 <li>
	 	edit sbibarre.php??? 
	<a href="?dossier=../&edit=oui&racine=../&page_titre=sbibarre.php">
	 Click Here
	 </a>
	 </li>
	 <li>
	 	edit administration .htaccess??? 
	<a href="?dossier=../&edit=oui&racine=../'.$diradmin.'/&page_titre=.htaccess">
	 Click Here
	 </a>
	 </li>
	 <li>
	 	edit administration .htpasswd??? 
	<a href="?dossier=../&edit=oui&racine=../'.$diradmin.'/&page_titre=.htpasswd">
	 Click Here
	 </a>
	 </li>	
	 <li>
	 	edit ../../index.php??? 
	<a href="?dossier=../../&edit=oui&racine=../../&page_titre=index.php">
	 Click Here
	 </a>
	 </li>	 	 
	 </ul>
</div>
<table>
<tr>
<td with="500"><b>'.@$page_titre. '</b> dans('.$racine.')</td>
<td>Dossiers</td>
<td>Fichiers</td>
</tr>
<tr>
<td with="500" valign="top">
<form method="post" action="'.$_SERVER['PHP_SELF'].''.@$get.'">
<input name="page_titre" type="text" value="'.@$page_titre.'" />
<input value="action" type="submit" /><br />
<b>Confirmer</b> l\' écrasement :
<input type="radio" name="action" id="action" value="ecraser" /><br />
Effacer le fichier :
<input name="action" type="radio" id="action" value="effacer" />
<input type="hidden" name="racine" value="'.$racine.'" /><br />
<a href="#source">Voir le code coloré???</a>
<br />
<textarea name="page_contenu" style="padding: 0 0 0 0; margin:0; width:500px; border:0; height:450px;">
'.htmlspecialchars($source).'
</textarea>
</form>';


########################
##
$les_dossiers = '';
$les_fichiers = '';

$racine = str_replace('//','/',$racine);
$dir = opendir($racine);
while($dossier = readdir($dir)) 
{
if(is_dir($racine.$dossier))
	{
	$les_dossiers .= '
<img width="32" height="32" src="'.$chemin.'_/img/dossier.png" />&nbsp;
	<b><a href="'.$_SERVER['PHP_SELF'].'?dossier='.$racine.$dossier.'">
'.$dossier.'</a></b>
<br />';
$startscript=$racine.$dossier;

$fileowneruid=fileowner($startscript);
$fileownerarray=posix_getpwuid($fileowneruid);
$fileowner=$fileownerarray['name'];
$filegroupuid=filegroup($startscript);
$filegrouparray=posix_getpwuid($filegroupuid);
$filegroup=$filegrouparray['name'];
$le_chmod = substr(sprintf('%o', fileperms($racine.$dossier)), -4);
$les_dossiers .= '&nbsp;';
	if(($dossier !== '.') && ($dossier !== '..'))
	{
	$les_dossiers .= '<a href="'.$_SERVER['PHP_SELF'].'?dossier_action=effacer&racine='.$racine.$dossier.'">>>>EFFACER<<<</a><br />
'.substr(sprintf('%o', fileperms($racine.$dossier)), -4)
.'<a href="'.$_SERVER['PHP_SELF'].'?chmod=oui&fichier='.$racine.$dossier.'&chmod_actuel='.$le_chmod.'">chmoder </a>
<div class="menu_gauche">U : '.$fileowner.'  G :  '.$filegroup.'</div>
	<hr />';

	}
	
	$les_dossiers .= '<br />';
	}
else
	{
	$les_fichiers .= '
<img width="32" height="32" src="'.$chemin.'_/img/fichier.png" />&nbsp;
	<a href="'.$_SERVER['PHP_SELF'].'?dossier='.$racine.'&edit=oui&racine='.$racine.'&page_titre='.$dossier.'">'.$dossier.'</a>
	&nbsp;
	<a target="_blank" href="'.$racine.$dossier.'" title="visualiser '.$racine.$dossier.'"><i>visu</i></a><br />'.substr(sprintf('%o', fileperms($racine.$dossier)), -4);
$startscript=$racine.$dossier;

$fileowneruid=fileowner($startscript);
$fileownerarray=posix_getpwuid($fileowneruid);
$fileowner=$fileownerarray['name'];
$filegroupuid=filegroup($startscript);
$filegrouparray=posix_getpwuid($filegroupuid);
$filegroup=$filegrouparray['name'];
$le_chmod = substr(sprintf('%o', fileperms($racine.$dossier)), -4);
$les_fichiers .= '
<a href="'.$_SERVER['PHP_SELF'].'?chmod=oui&fichier='.$racine.$dossier.'&chmod_actuel='.$le_chmod.'">chmoder </a>
<div class="menu_gauche">U : '.$fileowner.'  G :  '.$filegroup.'</div>
	<hr />';
	}
}
closedir($dir);
##
#########################

echo '
		</td>
		<td valign="top">
			Créer un dossier ici?<br>
			<form method="post">
			<input name="nom_dossier" />
			<input type="hidden" name="racine" value="'.$racine.'" />
			<input type="submit" value="creer" >
			</form>
			<br /> 
			'.$les_dossiers.'
		</td>
		<td valign="top">

			'.$les_fichiers.'

		</td>
	</tr>
</table>
<br />
<a name="source" href="#script">remonter à l\' édition du script?</a><br />La source de votre script <hr />
<div id="source">';
highlight_string($source);
echo '
</div>

<a name="source" href="#script">remonter à l\' édition du script?</a><br /><hr />';
b_html();
}
}
?>










