
<?php
$sbversion = '0.004b1';
$diradmin = 'gere';
?>

