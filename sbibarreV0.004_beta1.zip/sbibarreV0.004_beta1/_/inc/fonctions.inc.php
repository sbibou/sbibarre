<?php
require $chemin.'_/inc/constantes.inc.php';

#####################
## fonction header
function h_html(){
	global $chemin,$titre_page,$sbversion;
	if(file_exists($chemin.'_/inc/header.inc.php')){
	include $chemin.'_/inc/header.inc.php';
	}
	else
	{
	print '<!DOCTYPE html>
<html lang="en-us">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="sbibarre administration"/>
<title>'.$titre_page.'</title>
<meta http-equiv="content-type" content="text/hml; charset=UTF-8">
<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8"/>
<meta name="generator" content="sbiboucms V'.$sbversion.'" />
<meta name="author" content="olivier ros" />
<meta name="date" content="2018-07-07T02:22:22+0222" />
<meta name="copyright" content="sbibarre by olivier ros"/>
<meta name="keywords" content="cms, toolbar, sbibarre, frame, php, css, no mysql"/>
<meta name="description" content="this site is made with sbibarre on '.$_SERVER['SERVER_NAME'].'"/>
<meta name="ROBOTS" content="ALL"/>
<link rel="image_src" href="http://sbibou.com/favicon.png" />


</head>
<body>


<div align="left">
<h2><a href="'.$chemin.'">
<img width="52" height="52"   src="http://sbibou.com/favicon.png" />Sbibarre on '.$_SERVER['SERVER_NAME'].'</a></h2>
</div><div align="center">';
}}
###
##########

###################
## Fonction footer
function b_html(){
	global $chemin;
if(file_exists($chemin.'_/inc/footer.inc.php')){
include $chemin.'_/inc/footer.inc.php';
}
else{
echo '
<hr />&bull;




<div id="copyright" name="copyright" class="copyright">Olivier Ros &copy; 2009-2018
<br />Powered by <a href="https://sbibou.com/sbibarre/">Sbibarre</a></div>
<br /><br />
<P ALIGN="RIGHT"></P>
<div class="thatsallfoks"><a href="http://'.$_SERVER['SERVER_NAME'].'" title="'.$_SERVER['SERVER_NAME'].'">'.$_SERVER['SERVER_NAME'].' &copy; '.date('Y').'</a></div>
</body>
</html>';
}
}
##
##########

?>




