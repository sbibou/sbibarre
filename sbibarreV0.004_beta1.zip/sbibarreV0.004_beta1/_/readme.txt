##########################
##   Sbibarre concept !
##
## Version 0.002 Beta 1
##      06/21/2018 
#########################
##      Olivier Ros
##
##   olivier@sbibou.com
##



## Official page
http://sbibou.com/sbibarre

## Demo page
http://sbibou.com/sbibarre

## FAQ dedicated on rosaff
https://rosaff.com/support/knowledgebase.php?category=18 
   
## Support dedicated on rosaff
https://rosaff.com/support/index.php?a=add&catid=6

## Forum  dedicated on ssolos
https://ssolos.com/forum/phpBB3/viewforum.php?f=10

##
##########################
## ../_/readme.txt
##########################


Here is it!
 The sbibarre.
Just a small script for playing with frame and link.
new version with file editor
more complexity, htaccess & .htpasswd needed ;)


#########################
##How this system works?
#########################
## easy to use, just edit the text file 
##  sbibarre.txt
## I put link inside, you can see how it wrote

## name of category
@*@ : (name) : cat

## your links(as many as you want)
(url) : (text for url) : (target)

## end of category (carreful to white spaces) "@@@ :  : "
@@@ :  : 

## be carreful to always think to the white spaces
each element was delimited by " : "

you can add a lot of categories, just think to open and close each!

##########################
## sbibarre.inc.php
##########################

that's this file who translate the text file in html

## you can change the variable $filename 
## if you want to use an other text file


##########################
## sbibarre.php
##########################
## you can change the variable $first_page 
## to go to your website or favorite page

remember this script is in beta period and a lot of evolution will be in a middle time..

##
############################

############################
## $chemin/_/gere/index.php
############################
## Since Version0.002b1 there is a editor page for admin
## make your password directly after download files on your server
