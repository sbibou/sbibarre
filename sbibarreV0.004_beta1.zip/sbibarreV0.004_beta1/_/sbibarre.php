<?php
##########################
##   Sbibarre concept !
##
## Version 0.004 Beta 1
##       07/07/2018 
#########################
##      Olivier Ros
##
##   olivier@sbibou.com
## http://sbibou.com/sbibarre
##     
##
##
##########################
## ../_/sbibarre.php
##########################

## ouverture session
session_start();

## afficher ou pas les erreurs
##ini_set('display_errors','1');

## your website
$first_page = '../';

## if sbibarre.inc.php exist, we take it
if(is_file('./sbibarre.inc.php')){ require './sbibarre.inc.php'; }
else
{
$menu = '

<style>
#menu-accordeon {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
  width: 180px;
}
#menu-accordeon ul {
  padding:0;
  margin:0;
  list-style:none;
  text-align: center;
}
#menu-accordeon li {
   background-color:#729EBF; 
   background-image:-webkit-linear-gradient(top, #729EBF 0%, #333A40 100%);
   background-image: linear-gradient(to bottom, #729EBF 0%, #333A40 100%);
   border-radius: 6px;
   margin-bottom:2px;
   box-shadow: 3px 3px 3px #999;
   border:solid 1px #333A40
}
#menu-accordeon li li {
   max-height:0;
   overflow: hidden;
   transition: all .5s;
   border-radius:0;
   background: #444;
   box-shadow: none;
   border:none;
   margin:0
}
#menu-accordeon a {
  display:block;
  text-decoration: none;
  color: #fff;
  padding: 8px 0;
  font-family: verdana;
  font-size:1.2em
}
#menu-accordeon ul li a, #menu-accordeon li:hover li a {
  font-size:1em
}
#menu-accordeon li:hover {
   background: #729EBF
}
#menu-accordeon li li:hover {
   background: #999;
}
#menu-accordeon ul li:last-child {
   border-radius: 0 0 6px 6px;
   border:none;
}
#menu-accordeon li:hover li {
  max-height: 15em;
}
</style>



<h3>Sbibarre menu ;)
<a href="https://rosaff.com/support/index.php?a=add&catid=6" target="bas">(Support)</a>
<a href="https://rosaff.com/support/knowledgebase.php?category=18" target="bas">(Faq)</a>
<a href="http://sbibou.com/sbibarre" target="bas">(Page)</a>
<a href="https://ssolos.com/forum/phpBB3/viewforum.php?f=10" target="bas">(forum)</a></h3>
<hr />

	
					<ul id="menu-accordeon">
					<li><a href="#">My Favorites
					<ul>
					
<li><a href="http://sbibou.com" target="bas">Sbibou.com</a></li>
<li><a href="http://google.com" target="_blank">Google</a></li>
</ul>
					</li></ul>
						
					<ul id="menu-accordeon">
					<li><a href="#">Sbibou Network
					<ul>
					
<li><a href="http://sbibou.com" target="bas">Sbibou.com</a></li>
<li><a href="http://ssolos.com" target="bas">SSolos.com</a></li>
<li><a href="http://contactmymembers.com" target="bas">ContactMyMembers.com</a></li>
<li><a href="http://safelists.co" target="bas">Safelists.co</a></li>
<li><a href="http://listbuilderads.info" target="bas">ListBuilderAds</a></li>
<li><a href="http://rosaff.com" target="bas">RosAff.com</a></li>
<li><a href="http://o-ros.com" target="bas">O-Ros.com</a></li>
<li><a href="http://script.cool" target="bas">Script.cool</a></li>
<li><a href="http://olios.click" target="bas">Olios.click</a></li>
<li><a href="http://weblogeur.com" target="bas">weblogeur.com</a></li>
<li><a href="http://adsimum.com" target="bas">Adsimum.com</a></li>
<li><a href="http://2safelist.com" target="bas">2safelist</a></li>
</ul>
					</li></ul>
						
					<ul id="menu-accordeon">
					<li><a href="#">Tools
					<ul>
					
<li><a href="http://instantbannercreator.com/?rid=50763" target="bas">instantbannercreator</a></li>
<li><a href="http://intellibanners.com/?rid=16680" target="bas">intellibanners</a></li>
<li><a href="http://hitsconnect.com/?rid=45462" target="bas">hitsconnect.com</a></li>
<li><a href="http://www.entireweb.com/free_submission/#sbibou" target="_blank">entireweb</a></li>
<li><a href="https://techmasi.com/ping-sites/" target="bas">ping</a></li>
<li><a href="http://www.viralrotator.com/index.php?ref=3555" target="bas">viralrotator</a></li>
<li><a href="http://www.skyadboard.com/?pro=1126" target="bas">skyadboard</a></li>
<li><a href="http://listbuilderads.info/NewbieLessons" target="bas">NewbieLessons</a></li>
<li><a href="http://listbuilderads.info/store/storefront/index.php" target="bas">Opportunities</a></li>
</ul>
					</li></ul>
						
					<ul id="menu-accordeon">
					<li><a href="#">Links
					<ul>
					
<li><a href="http://1profitring.com/sbibou" target="bas">1profitring</a></li>
<li><a href="http://1tae.com/sbibou" target="bas">1tae</a></li>
<li><a href="http://577cash.com/sbibou" target="bas">577cash</a></li>
<li><a href="https://blaster.guru/sbibou" target="bas">blaster guru</a></li>
<li><a href="https://superlistexplode.com/sbibou" target="bas">superlistexplode</a></li>
<li><a href="https://wondermailer.com/sbibou" target="bas">wondermailer</a></li>
<li><a href="http://sbibou.com" target="bas">Sbibou.com</a></li>
<li><a href="http://google.com" target="_blank">Google</a></li>
</ul>
					</li></ul>
						
					<ul id="menu-accordeon">
					<li><a href="#">Social
					<ul>
					
<li><a href="http://ssolos.com/forum" target="bas">SSolos Forum</a></li>
<li><a href="http://safelists.co/forum" target="bas">Safelists.co Forum</a></li>
<li><a href="https://www.facebook.com/sbibousystem/" target="_blank">facebook</a></li>
</ul>
					</li></ul>
						</ul>
					</li></ul>
						
					<ul id="menu-accordeon">
					<li><a href="#">Engines
					<ul>
					
<li><a href="http://rosaff.com/php-chunked-xhtml" target="bas">PHP</a></li>
<li><a href="https://dev.mysql.com/doc/" target="_blank">Mysql</a></li>
<li><a href="https://www.w3schools.com/" target="_blank">w3schools</a></li>
</ul>
					</li></ul>
';

$menu2 = '<h2>hello</h2><a href="https://ssolos.com/editros" target="droite">editros?</a>';
}

## if we want a page
if (isset($_GET['page']))
{
		switch ($_GET['page']) {
## the top page			
    case "top":
        echo '	<a href="'.$first_page.'" target="bas"><b>Home</b>   </a> 
	<i>(<a href="'.$first_page.'" target="_parent" title="arreter la sbibarre">sortir</a>)</i>  
	<audio src="http://live.radiogrenouille.com/live"" controls  loop> 
        houpsss >> HTML5 audio not supported!!
	</audio><<< <a href="http://radiogrenouille.com/" target="bas">Go to Radio Grenouille Radio made in Marseille(France)</a> <<<
	<a href="http://radiogrenouille.com/" target="_blank"> in new window)</a>';
        break;
## the middle page        
    case 'bas':
        header('location:'.$first_page.'');
        break;
## the left (menu) page
    case 'gauche':
        echo $menu;;
        break;
## the right page
    case 'droite':
        echo $menu2;
        break;
## else, show an error page
            default:
       echo 'error <a href="'.$first_page.'"> return to site</a> or return to sbibarre <a href="?"> here</a>';

}
	
	
	
}
else
## else we show the structure frame page
{	##############
	##
	echo '

	
	<HTML>
<HEAD>
<title>Sbibarre on '.$_SERVER['SERVER_NAME'].'</title>

    <link rel="icon" sizes="64x64" href="http://sbibou.com/favicon.png" type="image/png">
</HEAD>
<FRAMESET ROWS="52,*">
<FRAME name="haut"  src="?page=top">
<FRAMESET cols="212, 80%, 16%">
<FRAME name="gauche" src="?page=gauche">

<FRAME name="bas" src="?page=bas">
<FRAME name="droite" src="?page=droite">
</FRAMESET>
</FRAMESET>
<noframe>
<p>this page use frame, if you can see it, here s the links inside</p>

<p><a href="?page=top"></a>top bar with Radio Grenouille made in marseille (france)</p>
<p><a href="?page=gauche">The menu</a></p>
<p><a href="?page=droite">other menu</a></p>
<p><a href="?page=bas">Where we show website</a></p>
what about change your browser? lol!
</noframe>
</HTML>
	
	';
	##
	##############
}
?>


