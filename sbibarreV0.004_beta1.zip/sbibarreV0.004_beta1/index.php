<?php
session_start();
$chemin = './';
require $chemin.'_/inc/fonctions.inc.php';
h_html();
#######################
## your content here ##
#######################
##
echo '
<h1>welcome to sbibarre</h1>
<p><a href="'.$chemin.'_/sbibarre.php" target="_parent">View it</a></p>
';
## is folder "gere" password protected?
if((is_file($chemin.'_/'.$diradmin.'/.htaccess')) && (is_file($chemin.'_/'.$diradmin.'/.htpasswd')))
{echo 'Sbibarre successfully installed - sbibarre version '.$sbversion.'</b>
<br />';
## Are you connected?
if(isset($_SESSION['admin'])){echo '<a target="bas"  href="'.$chemin.'_/gere"><b>Administration</b></a><hr />';}
}

##
#########################
## End of your content ##
#########################

b_html();
?>














